COURTESY OF HELTELO LABS. PUBLIC RESEARCH AND DEVELOPMENT R&D
All rights reserved. Lua is MIT-LICENSED Software developed by PUC RIO.


LUA 5.1.5 BUILDS FOR 32 BIT MS-DOS SYSTEMS
*-*-*-*-*-*-*-*-*

As a experimental project, we have decided to build the most
popular lua version (Lua 5.1) for MS-DOS systems. Compiled
with optimizations it features the full standard library and
ANSI interpreter.

It was built with the DJGPP project.


The distribution contains the following:
- CWSDPMI: 32-bit DPMI host for DOS
- LIBLUA.A: object file archive from compilation (safe to remove)
- LUA: Lua interpreter and command-line
- LUAC: Lua compiler/assembler


Have fun!
